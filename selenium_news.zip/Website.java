import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.*;
import java.io.PrintWriter;



public class Website {
    public static void main(String [] args){        
        System.setProperty("webdriver.chrome.driver","chromedriver.exe");
        News myNews = new News();
        myNews.newsAutomation();


    }
    public static void writer(String value){
        try {
            PrintWriter writer = new PrintWriter("news.html","UTF-8");
            writer.write(value);
            System.out.print(value);
        }
        catch (FileNotFoundException f){

        }
        catch (UnsupportedEncodingException un){}
    }

}
