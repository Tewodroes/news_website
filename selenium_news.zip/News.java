import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
 import java.util.List;


public class News{

    public static WebDriver driver = new ChromeDriver();

    public static void main(String [] args){        
        System.setProperty("webdriver.chrome.driver","chromedriver.exe");
        newsAutomation();
        driver.close();

    }
    public static String newsAutomation() {
        driver.get("https://addisfortune.net/");
        String title = driver.getTitle();
        String currentUrl = driver.getCurrentUrl();
        String pageSource = driver.getPageSource();
        WebElement lists = driver.findElement(By.xpath("//*[@id=\"addisfortune-main\"]/div/div[1]/div[2]/div"));
        List<WebElement> headers= lists.findElements(By.tagName("h3"));
        List<WebElement> headers_body= lists.findElements(By.className("row"));

        System.out.println(headers.size());
        String Automated_page = "<head><link rel=\"stylesheet\" type=\"text/css\" href=\"newcss.css\"></head>";
        Automated_page= Automated_page + "<div class=\"conatain\">";
        for(int i = 0 ;i<headers.size() ;i++){

            if(headers.size()<1){break;}
            Automated_page = Automated_page + "<div class=\"single\">";
            Automated_page = Automated_page +headers.get(i).getAttribute("innerHTML");
            Automated_page = Automated_page +headers_body.get(i).findElement(By.className("span2")).getAttribute("innerHTML");
            Automated_page = Automated_page +headers_body.get(i).findElement(By.className("span4")).getAttribute("innerHTML");
            Automated_page = Automated_page +"</div>";
        }
        Automated_page = Automated_page +"</div>";
        return  Automated_page;
    }

}
